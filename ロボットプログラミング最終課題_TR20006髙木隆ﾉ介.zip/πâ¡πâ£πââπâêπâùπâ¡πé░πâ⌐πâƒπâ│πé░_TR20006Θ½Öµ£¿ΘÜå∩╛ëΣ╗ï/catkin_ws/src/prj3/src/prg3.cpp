// prg3.cpp

#include <iostream>
#include <vector>
#include "ros/ros.h"
#include "std_msgs/Float64.h"
#include "sensor_msgs/JointState.h"

#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

#include "prg3.h"

static const std::string OPENCV_WINDOW = "OpenCV Image Window";

class ImageConverter
{
private:
    ros::NodeHandle nh_;
    image_transport::ImageTransport it_;
    image_transport::Subscriber image_sub_; // 画像データのサブスクライバ
    image_transport::Publisher  image_pub_; // 画像データのパブリッシャ
    cv_bridge::CvImagePtr cv_ptr; // 画像データを記録しておく場所
    cv::Mat cv_tmpimage; // 変換後の画像データを入れておく仮の場所
    char *sname, *pname; // 画像データのサブスクライバ, パブリッシャの名前
    int id; // カメラの ID
  
public:
    ImageConverter(int n, char sn[], char pn[]) : it_(nh_) // コンストラクタ
    {
        id = n;
        sname = sn;
        pname = pn;
// サブスクライバ、パブリッシャの用意
// サブスクライバは、カメラから画像のメッセージを受け取る度にimageCallback() で処理する
	image_sub_ = it_.subscribe(sname, 1, &ImageConverter::imageCallback, this);
// パブリッシャは ROS で画像を扱えるように変換後の画像をパブリッシュする
	image_pub_ = it_.advertise(pname, 1);
    }

    ~ImageConverter() // デストラクタ
    { 
// 表示に使ったWindowを破棄する
        cv::destroyWindow(OPENCV_WINDOW);
    }

    void imageCallback(const sensor_msgs::ImageConstPtr& msg)
    {
        try
	{
// ROS から OpenCV の形式に toCvCopy() で変換、cv_ptr->image が cv::Mat フォーマット
	    cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
	}
	catch (cv_bridge::Exception& e) // もしエラーがあれば
	{
	    ROS_ERROR("cv_bridge exception: %s", e.what());
	    return;
	}
// 複数のカメラ画像を同時に imshow() で表示すると落ちるので一台に限定する
// id を 2 に変えると手首のカメラの画像を表示できる
        static int count = 0, f1 = 0, f2 = 0;
	if (1 == id && 0 == count % 3) { 
	    cv::imshow(sname, cv_ptr -> image);
	    cv::waitKey(5); // 5ms 待つ
// OpenCV による画像の加工の例、画像の大きさを半分にして表示する
	    cv::resize(cv_ptr -> image, cv_tmpimage, cv::Size(), 0.5, 0.5);
// 1 台のカメラの画像なら複数枚表示しても問題ない
	    cv::imshow("Half", cv_tmpimage);
	    cv::waitKey(5); // 5ms 待つ
	}
// 画像をパブリッシュ, OpenCVからROS形式にtoImageMsg()で変換すると ROS のツールで扱える
	image_pub_.publish(cv_ptr -> toImageMsg());

// 2 台のカメラの動作確認用に途中で 1 回画像をファイルに書き出してみる
	if (1 == id && 100 < count++ && 0 == f1) {imwrite("/tmp/cam1.ppm", cv_ptr -> image); f1 = 1;}
	if (2 == id && 100 < count++ && 0 == f2) {imwrite("/tmp/cam2.ppm", cv_ptr -> image); f2 = 1;}
    }
};

const float MotorSenseITVL = 0.01; // モータの角度を読み出す間隔、秒
const float MotorCtrlITVL  = 0.01; // モータの角度を指示する間隔、秒
const float AIITVL = 0.01;         // 行動計画 AI の計算をする間隔、秒

// 次のポインタは、モータの状態を表す2個の配列を、オブジェクト外の AIの関数 
// intelligence() からまとめてアクセスできるようにするためにある。

C1 *gMotor;

void monitorJointState(const sensor_msgs::JointState::ConstPtr& js);
void intelligence(const ros::TimerEvent&);

int main(int argc, char **argv)
{
    float param[NUMPARAM];

    ros::init(argc, argv, "joint_controller");

// モータの角度を取得する subscriber の設定
// モータ角度の publisher の設定は、config/prg3.yaml の先頭にある
    ros::NodeHandle nh;
    ros::Subscriber p_sub = nh.subscribe("/prj3/joint_states", 128, monitorJointState);

// 次の行動を決める AI をタイマーにより周期的に呼び出す
    ros::Timer timer = nh.createTimer(ros::Duration(AIITVL), intelligence);

// カメラ画像を取り込むクラスのオブジェクト、中でコールバック関数が動く
// カメラ１台にインスタンスが１個必要   
    ImageConverter ic1(1, "/prj3/camera1/image_raw", "/prj3/image_topic1");
    ImageConverter ic2(2, "/prj3/camera2/image_raw", "/prj3/image_topic2");
    
// この後、各関節に１個ずつ、コントローラのインスタンスを順次生成する

    param[0] = MODENONE;    // 制御の仕方、シンプルな PID 制御のみ
//  param[0] = MODEPROFILE; // 制御の仕方、プロファイルにより細かく目標角度を決める

    C1 motor[NUMJOINTS] = {
	C1((char*)"/prj3/a1j1_pos_con/command", A1J1, param), // ArmLeft1 shoulder
	C1((char*)"/prj3/a1j2_pos_con/command", A1J2, param), // ArmLeft1 elbow1
	C1((char*)"/prj3/a1j3_pos_con/command", A1J3, param), // ArmLeft1 elbow2
	C1((char*)"/prj3/a1j4_pos_con/command", A1J4, param), // ArmLeft1 wrist1
	C1((char*)"/prj3/a1j5_pos_con/command", A1J5, param), // ArmLeft1 wrist2
	C1((char*)"/prj3/a1j6_pos_con/command", A1J6, param), // ArmLeft1 wrist3
	C1((char*)"/prj3/a1j7_pos_con/command", A1J7, param), // ArmLeft1 Hand Finger1
	C1((char*)"/prj3/a1j8_pos_con/command", A1J8, param), // ArmLeft1 Hnad Finger2
	C1((char*)"/prj3/a2j1_pos_con/command", A2J1, param), // ArmLeft2 shoulder
	C1((char*)"/prj3/a3j1_pos_con/command", A3J1, param), // ArmLeft3 shoulder
	C1((char*)"/prj3/a4j1_pos_con/command", A4J1, param), // ArmRight1 shoulder
	C1((char*)"/prj3/a5j1_pos_con/command", A5J1, param), // ArmRight2 shoulder
	C1((char*)"/prj3/a6j1_pos_con/command", A6J1, param), // ArmRight3 shoulder
	C1((char*)"/prj3/a7j1_pos_con/command", A7J1, param), // Neck 1
	C1((char*)"/prj3/a7j2_pos_con/command", A7J2, param), // Neck 2
    };
    gMotor = motor; // グローバルにアクセスできるようにするためポインタにアドレスを入れる

    gMotor[A1J3].ctrlmode = MODEPROFILE2;
    gMotor[A1J3].duration = 6;
    gMotor[A1J4].ctrlmode = MODEPROFILE2;
    gMotor[A1J4].duration = 6;
    gMotor[A1J5].ctrlmode = MODEPROFILE2;
    gMotor[A1J5].duration = 6;
    gMotor[A1J6].ctrlmode = MODEPROFILE2;
    gMotor[A1J6].duration = 6;

    gMotor[A7J1].ctrlmode = MODEPROFILE;
    gMotor[A7J1].duration = 6;
    gMotor[A7J2].ctrlmode = MODEPROFILE;
    gMotor[A7J2].duration = 6;
    
//  ros::spin();
    ros::AsyncSpinner spinner(4); // Use 4 threads
    spinner.start();
    ros::waitForShutdown();

    return 0;
}

// 角度データが届く度に呼び出されるこの関数で、各関節の現在の角度を記録する。
void monitorJointState(const sensor_msgs::JointState::ConstPtr& js)
{
    static int c = 0;

    for (int i = 0; i < NUMJOINTS; i++) {
        gMotor[i].anglenow.data = js -> position[i]; // 配列に格納する
    }
    
    if (0 == c % 100) { // １秒に１回表示する
        for (int i = 0; i < NUMJOINTS; i++) {
//	    printf("%5.2f ", anglenow[i].data); // ここでは表示しているだけ
	}
    }
    c++;
}

// 周期的に呼び出されるこの関数で行動計画を決めて、各関節の目標角度を指定する。
// ここで指定した目標角度は各関節のコントローラからモータに送られる。
void intelligence(const ros::TimerEvent&)
{
    static int timer = 0;
    static int timer2= 0;
    static int cycle = 1000;
    static int mode = 0;

    if (0 == timer) { // 初期値、最初だけ有効
        for (int i = 0; i < NUMJOINTS; i++) gMotor[i].targetangle.data = 0;
    }
    gMotor[A1J1].targetangle.data =-M_PI / 2.0; // 前脚を前に　９０度曲げておく 

    gMotor[A1J7].targetangle.data = M_PI / 4.0; // 指　を少し開いておく
    gMotor[A1J8].targetangle.data =-M_PI / 4.0; // 指　を少し開いておく

    gMotor[A3J1].targetangle.data = M_PI / 3.0; // 後脚を後ろに６０度曲げておく
    gMotor[A4J1].targetangle.data = M_PI / 2.0; // 前脚を前に　９０度曲げておく
    gMotor[A6J1].targetangle.data =-M_PI / 3.0; // 後脚を後ろに６０度曲げておく

    if (cycle == timer) { // cucle*0.01 秒ごとに手首を９０度回転
        timer = 0;
        if (0.0 == gMotor[A1J3].targetangle.data) gMotor[A1J3].targetangle.data = M_PI / 2.0; // 肘
	else                                      gMotor[A1J3].targetangle.data = 0.0;
        if (0.0 == gMotor[A1J4].targetangle.data) gMotor[A1J4].targetangle.data = M_PI / 2.0; // 手首
	else                                      gMotor[A1J4].targetangle.data = 0.0;
        if (0.0 == gMotor[A1J5].targetangle.data) gMotor[A1J5].targetangle.data = M_PI / 2.0; // 手首
	else                                      gMotor[A1J5].targetangle.data = 0.0;
        if (0.0 == gMotor[A1J6].targetangle.data) gMotor[A1J6].targetangle.data = M_PI / 2.0; // 手首
	else                                      gMotor[A1J6].targetangle.data = 0.0;
        if (M_PI / 2.0 == gMotor[A7J1].targetangle.data) gMotor[A7J1].targetangle.data =-M_PI / 2.0; // 首　横
	else                                             gMotor[A7J1].targetangle.data = M_PI / 2.0;
        if (M_PI / 4.0 == gMotor[A7J2].targetangle.data) gMotor[A7J2].targetangle.data =-M_PI / 4.0; // 首　縦
	else                                             gMotor[A7J2].targetangle.data = M_PI / 4.0;
    }
    timer++;
    if (cycle*2 == timer2) { // cucle*0.01 *2 秒ごとに制御を切り替え
        timer2 = 0;
	printf("ctrlmode %d\n", mode % 3);
	gMotor[A1J3].ctrlmode = mode % 3;
	gMotor[A1J3].duration = 6;
	gMotor[A1J4].ctrlmode = mode % 3;
	gMotor[A1J4].duration = 6;
	gMotor[A1J5].ctrlmode = mode % 3;
	gMotor[A1J5].duration = 6;
	gMotor[A1J6].ctrlmode = mode++ % 3;
	gMotor[A1J6].duration = 6;
    }
    timer2++;
}

// 各関節のコントローラのインスタンス生成と初期化
C1::C1(char *name, int idnum, float param[NUMPARAM])
{
    c_pub = nh.advertise<std_msgs::Float64>(name, 1000); // 角度をモータに publish するため

    // timerCallback は周期的に呼び出され、モータの目標角度を決める
    timer = nh.createTimer(ros::Duration(MotorCtrlITVL), &C1::timerCallback, this);

    id = idnum; // 渡された id 値をオブジェクトの変数 id にセットする
    ctrlmode = param[0]; // 制御の種類を決める

    lasttarget = -123.45; // 目標角度の記憶用変数、初期値は意味のない仮の値
    duration = 8;     // この時間をかけてモータは回転する sec
    count = 0;        // プロファイルをどこまで実行したか覚えておく
    for (int i = 0; i < PROFSIZE; i++) profile[i] = 0;
}

// 動作中はこの関数が周期的に呼び出され、関節の目標角度を送信する
void C1::timerCallback(const ros::TimerEvent&)
{
    if (fabs(targetangle.data - anglenow.data) < 0.1 && MOVING == state) {
        state = DONE; // 目標角度に到達したら、完了のフラグをセットする
        fprintf(stderr, "!%d(%d) ", id, count);
    }
    
    std_msgs::Float64 val;     // モータに送る角度を入れる
    
    if (MODENONE == ctrlmode) { // 単純な PID 制御
        if (0.1 < fabs(targetangle.data - lasttarget)) {  // 目標角度が変更されたか？
	    state = MOVING; // 目標角度が変更されたら、動作中のフラグをセットする
	    lasttarget = targetangle.data;
	    count = 0;
	}
        val.data = targetangle.data;
	count++;
    }

    if (MODEPROFILE == ctrlmode) { // プロファイルによって目標を調整する
        if (0.1 < fabs(targetangle.data - lasttarget)) { // 目標角度が変更されたら、新たにプロファイルを計算する
//	    printf("targetangle %.5f\n", targetangle.data);
	    state = MOVING; // 目標角度が変更されたら、動作中のフラグをセットする
	    lasttarget = targetangle.data;
	    width = targetangle.data - anglenow.data;
	    goal = duration / MotorCtrlITVL;
	    count = 0;

	    int i; // ここからプロファイルの生成
	    float start = anglenow.data; // 開始角度
	    for (i = 0; i < goal * AttackTime; i++) { // 立ち上がりのプロファイル
	        profile[i] = start + (width * Attack * (i+1) / (goal * AttackTime));
	    }
	    start = profile[i-1];
	    for (i = goal * AttackTime; i < goal * (AttackTime+SustainTime); i++) { // 中間部のプロファイル
	        profile[i] = start + (width * Sustain * (i-(goal * AttackTime)+1) / (goal * SustainTime));
	    }
	    start = profile[i-1];
	    for (i = goal * (AttackTime+SustainTime); i < goal; i++) { // 立ち下がりのプロファイル
	        profile[i] = start + (width * Release * (i-(goal * (AttackTime+SustainTime))+1) / (goal * ReleaseTime));
	    }
	    for (i = goal; i < PROFSIZE; i++) profile[i] = targetangle.data;
	}
	if (PROFSIZE - 1 < count) count = PROFSIZE - 1; // 長時間同じ姿勢が続く場合は配列の末尾を超えないように

	val.data = profile[count]; // 計算したプロファイルに沿った値を順番に送る
	count++;
    }

    if (MODEPROFILE2 == ctrlmode) { // プロファイル２によって目標を調整する
        if (0.1 < fabs(targetangle.data - lasttarget)) { // 目標角度が変更されたら、新たにプロファイルを計算する
//	    printf("targetangle %.5f\n", targetangle.data);
	    state = MOVING; // 目標角度が変更されたら、動作中のフラグをセットする
	    lasttarget = targetangle.data;
	    width = targetangle.data - anglenow.data;
	    goal = duration / MotorCtrlITVL / 2;
	    count = 0;

	    int i; // ここからプロファイルの生成
	    for (i = 0; i < goal; i++) { // 立ち上がりのプロファイル
	      profile[i] = anglenow.data + width * (i+1) / goal;
	    }
	    for (i = goal; i < PROFSIZE; i++) profile[i] = targetangle.data;
	}
	if (PROFSIZE - 1 < count) count = PROFSIZE - 1; // 長時間同じ姿勢が続く場合は配列の末尾を超えないように

	val.data = profile[count]; // 計算したプロファイルに沿った値を順番に送る
	count++;
    }

    c_pub.publish(val); // ここでモータに送られる
}

// もし異なる動作のコントローラを使いたい場合はこのように別のオブジェクトにする
C2::C2(char *name, int idnum, float param[NUMPARAM])
{
    c_pub = nh.advertise<std_msgs::Float64>(name, 1000);

    timer = nh.createTimer(ros::Duration(0.01), &C2::timerCallback, this);

    id = idnum; // 渡された値を変数id にセットする
}

// 別のコントローラ
void C2::timerCallback(const ros::TimerEvent&)
{
    std_msgs::Float64 pos;
    
    pos.data = M_PI / 2.0;

    c_pub.publish(pos);
}

