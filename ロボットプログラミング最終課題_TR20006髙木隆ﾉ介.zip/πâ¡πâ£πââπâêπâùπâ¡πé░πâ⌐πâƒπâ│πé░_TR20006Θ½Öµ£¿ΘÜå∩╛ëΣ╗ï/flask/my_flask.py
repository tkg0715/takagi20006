#! /usr/bin/env python
# coding: utf-8

import numpy as np
import rospy
import os
import time
import ctypes
import cv2
from multiprocessing import Array, Value, Process
from flask import Flask, render_template, request, session, redirect, url_for
from std_msgs.msg import UInt32, Float64
from sensor_msgs.msg import Image 
from cv_bridge import CvBridge

NW = 640
NH = 480
IMGSIZE = (NH, NW, 3)
img = np.zeros(IMGSIZE, dtype=np.uint8)

app = Flask(__name__)
app.secret_key = 'secret_key'
ROOT = app.root_path
WAIT = 0
DOCOPY = 1
imgcopy = Array('i', 1)
array = Array(ctypes.c_uint8, 480*640*3)

def rcallback(msg):
    try:
        bridge = CvBridge()
        global img
        img = bridge.imgmsg_to_cv2(msg, "bgr8")
        cv2.imshow('image', img)
        cv2.waitKey(5)
    except Exception as err:
        print(err)

def rinit(array, flag):
    rospy.init_node('webnode', disable_signals=True)
    rsub = rospy.Subscriber("/prj3/camera1/image_raw", Image, rcallback)
    rpub = rospy.Publisher('/webpub', UInt32, queue_size=10)
    rate = rospy.Rate(30) # 30 hz
    while not rospy.is_shutdown():
        dummy = 0
        if DOCOPY == flag[0] :
##          print 'ROS thread copying', flag[0], id(flag)
            global img
            cv2.imwrite("static/cam1.jpg", img)
            cv2.waitKey(5)
            flag[0] = WAIT
##          print 'ROS thread set 0', flag[0], id(flag)
        rate.sleep()

@app.context_processor
def override_url_for():
    return dict(url_for=dated_url_for)

def dated_url_for(dir, **values):
    if dir == 'static':
        filename = values.get('filename', None)
        if filename:
            file_path = os.path.join(app.root_path, dir, filename)
            values['q'] = int(os.stat(file_path).st_mtime)
    return url_for(dir, **values)
        
@app.route('/', methods=['GET', 'POST'])
def toppage():
    global imgcopy
    imgcopy[0] = DOCOPY
##  print 'Flask webroute set 1', imgcopy[0], id(imgcopy)
    while DOCOPY == imgcopy[0] :
##      print 'Flask waiting', imgcopy[0], id(imgcopy)
        time.sleep(0.125)
    session['p_str1'] = request.form.get('f_str1', '')
    session['p_str2'] = request.form.get('f_str2', '')
    session['p_radio1'] = request.form.get('f_radio1', '')
    session['p_radio2'] = request.form.get('f_radio2', '')
    return redirect(url_for('postprocess'))

@app.route('/postprocess')
def postprocess():
    if ('p_str1' not in session) and ('p_str2' not in session) and \
       ('p_radio1' not in session) and ('p_radio2' not in session):
        return redirect(url_for('/'))
    return render_template('my_flask.html', title='Top', j_rootpath = ROOT)
    
@app.route('/p1/')
def hello_world():
    msg = UInt32()
    msg.data = 1
    wpub.publish(msg)
    return 'Hello, World!'

if __name__ == "__main__":
    imgcopy[0] = DOCOPY
    p = Process(target=rinit, args=[array, imgcopy])
    p.start()
    app.run(debug=True, host='0.0.0.0', port=5000)

## http://127.0.0.1:5000/
